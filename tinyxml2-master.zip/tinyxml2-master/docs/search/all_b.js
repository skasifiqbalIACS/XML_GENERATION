var searchData=
[
  ['name_0',['Name',['../classtinyxml2_1_1_x_m_l_attribute.html#a5a5c135d24cce7abda6f17301c6274d8',1,'tinyxml2::XMLAttribute::Name()'],['../classtinyxml2_1_1_x_m_l_element.html#abd36e34e4428a8eeeffbe87eab0b124d',1,'tinyxml2::XMLElement::Name()']]],
  ['newcomment_1',['NewComment',['../classtinyxml2_1_1_x_m_l_document.html#a386df0befd06aadb5e0cd21381aa955a',1,'tinyxml2::XMLDocument']]],
  ['newdeclaration_2',['NewDeclaration',['../classtinyxml2_1_1_x_m_l_document.html#ae519030c0262fa2daff8993681990e16',1,'tinyxml2::XMLDocument']]],
  ['newelement_3',['NewElement',['../classtinyxml2_1_1_x_m_l_document.html#a3c335a700a43d7c363a393142a23f234',1,'tinyxml2::XMLDocument']]],
  ['newtext_4',['NewText',['../classtinyxml2_1_1_x_m_l_document.html#acece5de77a0819f2341b08c1e1ed9987',1,'tinyxml2::XMLDocument']]],
  ['newunknown_5',['NewUnknown',['../classtinyxml2_1_1_x_m_l_document.html#a4954f502c5fd7f49de54c3c0c99bb73d',1,'tinyxml2::XMLDocument']]],
  ['next_6',['Next',['../classtinyxml2_1_1_x_m_l_attribute.html#aa8c7cf4c94a636ae75046658e551614e',1,'tinyxml2::XMLAttribute']]],
  ['nextsibling_7',['NextSibling',['../classtinyxml2_1_1_x_m_l_node.html#af986c568061b020cf6232bec091388c0',1,'tinyxml2::XMLNode::NextSibling()'],['../classtinyxml2_1_1_x_m_l_handle.html#aad2eccc7c7c7b18145877c978c3850b5',1,'tinyxml2::XMLHandle::NextSibling()']]],
  ['nextsiblingelement_8',['NextSiblingElement',['../classtinyxml2_1_1_x_m_l_node.html#a14ea560df31110ff07a9f566171bf797',1,'tinyxml2::XMLNode::NextSiblingElement()'],['../classtinyxml2_1_1_x_m_l_handle.html#ae41d88ee061f3c49a081630ff753b2c5',1,'tinyxml2::XMLHandle::NextSiblingElement()']]],
  ['nochildren_9',['NoChildren',['../classtinyxml2_1_1_x_m_l_node.html#ac3ab489e6e202a3cd1762d3b332e89d4',1,'tinyxml2::XMLNode']]]
];
