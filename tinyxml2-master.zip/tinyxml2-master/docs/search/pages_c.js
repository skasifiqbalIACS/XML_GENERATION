var searchData=
[
  ['xml_0',['Get information out of XML',['../_example_3.html',1,'']]],
  ['xml_20file_1',['Load an XML File',['../_example_1.html',1,'']]],
  ['xml_20from_20char_20buffer_2',['Parse an XML from char buffer',['../_example_2.html',1,'']]]
];
