var searchData=
[
  ['text_20information_0',['Read attributes and text information.',['../_example_4.html',1,'']]],
  ['tinyxml_202_1',['TinyXML-2',['../index.html',1,'']]]
];
